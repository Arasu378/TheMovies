export const environment = {
  production: true,
  KEY: '',
  URL: 'https://api.themoviedb.org/3/'
};
