import { ImagesPipe } from './images.pipe';

describe('ImagesPipe', () => {
  it('create an instance', () => {
    const pipe = new ImagesPipe();
    expect(pipe).toBeTruthy();
  });
});
