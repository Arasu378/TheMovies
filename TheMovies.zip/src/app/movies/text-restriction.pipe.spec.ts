import { TextRestrictionPipe } from './text-restriction.pipe';

describe('TextRestrictionPipe', () => {
  it('create an instance', () => {
    const pipe = new TextRestrictionPipe();
    expect(pipe).toBeTruthy();
  });
});
